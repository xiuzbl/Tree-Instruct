# vLLM Eval

**Working in progress... Stay tuned!**

🚀 Efficiently evaluate large language models (LLMs) in just 5 minutes (full eval suite) !

## Suite Included

### Zero-shot Multiple-Choice

 - AGIEval
 - BBH
 - TruthfulQA

### Few-shot CoT

 - BBH
 - GSM8k
